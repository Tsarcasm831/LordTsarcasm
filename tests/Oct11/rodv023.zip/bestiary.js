// bestiary.js

document.addEventListener('DOMContentLoaded', () => {
    initializeBestiary();
    setupEventListeners();
});

function initializeBestiaryUI() {
    // Add this to ensure rendering when opened
    document.getElementById('openBestiary').addEventListener('click', () => {
        openBestiary();
        renderBestiary();
    });
}


/**
 * Initializes the bestiary by loading all species data.
 */
function initializeBestiary() {
    window.bestiary = {}; // Initialize the bestiary object

    const speciesData = {
        humans: {
            highResImage: 'images/high-res/humans.jpg',
            name: 'Humans',
            description: 'Humans, once masters of a thriving world, now traverse the remnants, their spirits unbroken. Their resilience and adaptability have become legendary.',
            extendedDescription: 'In the aftermath of cataclysmic events that shattered their civilization, humans have learned to adapt to the harshest of environments. They harness remnants of old technology and combine it with newfound survival techniques. Their cities lie in ruins, but from the ashes, they build shelters, forge alliances, and continue to dream of a better future. The human spirit is unyielding, and their creativity knows no bounds as they navigate the challenges of a changed world.',
            history: 'Once the dominant species on Earth, humans thrived with advanced technology and sprawling civilizations. However, a series of cataclysmic events, possibly self-inflicted, brought about the downfall of their societies. Now, they live in smaller communities, scavenging the remnants of their past while striving to rebuild. Tales are told of the old world, serving both as a warning and a beacon of hope for future generations.',
            abilities: 'Humans possess remarkable adaptability, able to adjust to new environments and situations swiftly. Their resilience is legendary, enabling them to endure hardships that would break other species. Technological ingenuity allows them to repurpose old technologies and innovate solutions with limited resources. They are also known for their diplomatic abilities, often acting as mediators between other races.',
            culture: 'Human culture is a rich tapestry woven from countless traditions, languages, and beliefs. In the post-apocalyptic world, they have developed a culture centered around community, survival, and storytelling. Music, art, and literature have become means of preserving their history and inspiring hope. Despite their fragmented state, humans place great value on cooperation and learning from the mistakes of the past.',
            modelName: 'humans',
            stats: {
                STR: 80,
                DEX: 50,
                AGI: 60,
                VIT: 70,
                COM: 40,
                INT: 65,
                PER: 55,
                CHA: 70,
                PSY: 30
            }
        },
        // ... (rest of the species data)
        custom: {
            highResImage: 'images/high-res/custom.jpg',
            name: 'Custom',
            description: 'Create a unique race with tailored abilities to suit your individual play style. The possibilities are endless!',
            extendedDescription: 'The creation is limited only by imagination and resourcefulness, allowing players a vast array of options.',
            history: 'Each custom race holds a unique story, reflecting the creator\'s vision of strengths and culture.',
            abilities: 'Varying abilities based on the creator\'s choice, they encompass a wide range of gameplay experiences.',
            culture: 'A culture shaped by individual creativity ensures that each creation is as unique as its maker.',
            modelName: 'custom',
            stats: {
                STR: 60,
                DEX: 60,
                AGI: 60,
                VIT: 60,
                COM: 60,
                INT: 60,
                PER: 60,
                CHA: 60,
                PSY: 60
            }
        }
        // Add additional species following the same structure if necessary
    };

    window.bestiary = speciesData;
}

/**
 * Sets up event listeners for bestiary interactions.
 */
function setupEventListeners() {
    const openBestiaryButton = document.getElementById('openBestiary');
    const closeBestiaryButton = document.getElementById('closeBestiary');
    const bestiaryModal = document.getElementById('bestiaryModal');

    if (openBestiaryButton) {
        openBestiaryButton.addEventListener('click', openBestiary);
    }

    if (closeBestiaryButton) {
        closeBestiaryButton.addEventListener('click', closeBestiary);
    }

    window.addEventListener('click', (event) => {
        if (event.target === bestiaryModal) {
            closeBestiary();
        }
    });

    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && bestiaryModal.classList.contains('show')) {
            closeBestiary();
        }
    });
}

/**
 * Renders the bestiary content by listing all races.
 */
function renderBestiary() {
    const bestiaryDiv = document.getElementById('bestiaryContent');
    bestiaryDiv.innerHTML = ''; // Clear existing content

    for (const key in bestiary) {
        if (bestiary.hasOwnProperty(key)) {
            const creature = bestiary[key];
            const creatureCard = document.createElement('div');
            creatureCard.classList.add('creature-card');

            creatureCard.innerHTML = `
                <img src="${creature.highResImage}" alt="${creature.name}" class="creature-image">
                <div class="creature-info">
                    <h3>${creature.name}</h3>
                    <p>${creature.description}</p>
                    <button class="view-details-button" data-creature="${key}">View Details</button>
                </div>
            `;

            bestiaryDiv.appendChild(creatureCard);
        }
    }

    // Add event listeners to view details buttons
    const viewDetailsButtons = document.querySelectorAll('.view-details-button');
    viewDetailsButtons.forEach(button => {
        button.addEventListener('click', () => {
            const creatureKey = button.getAttribute('data-creature');
            displayRaceDetails(creatureKey);
        });
    });
}

/**
 * Displays detailed information about a selected race in a modal.
 * @param {string} creatureKey - The key of the creature in the bestiary data.
 */
function displayRaceDetails(creatureKey) {
    const creature = bestiary[creatureKey];
    if (!creature) return;

    const detailsModal = document.getElementById('creatureDetailsModal');
    const detailsContent = document.getElementById('creatureDetailsContent');

    detailsContent.innerHTML = `
        <img src="${creature.highResImage}" alt="${creature.name}" class="creature-detail-image">
        <h2>${creature.name}</h2>
        <p>${creature.extendedDescription}</p>
        <h3>History</h3>
        <p>${creature.history}</p>
        <h3>Abilities</h3>
        <p>${creature.abilities}</p>
        <h3>Culture</h3>
        <p>${creature.culture}</p>
        <h3>Stats</h3>
        <div class="stats-container">
            ${generateStatsHTML(creature.stats)}
        </div>
        <div id="model-container-${creatureKey}" class="model-container"></div>
    `;

    detailsModal.classList.add('show');
    detailsModal.setAttribute('aria-hidden', 'false');

    // Close Race Details Modal
    const closeDetailsButton = detailsModal.querySelector('.close-details');
    closeDetailsButton.addEventListener('click', () => {
        closeCreatureDetails(creatureKey);
    });

    // Close when clicking outside the modal content
    detailsModal.addEventListener('click', (event) => {
        if (event.target === detailsModal) {
            closeCreatureDetails(creatureKey);
        }
    });

    // Load 3D model
    loadCreatureModel(creature.modelName, `model-container-${creatureKey}`);
}

/**
 * Generates HTML for the stats section.
 * @param {object} stats - The stats object containing various stat values.
 * @returns {string} - The generated HTML string for stats.
 */
function generateStatsHTML(stats) {
    let statsHTML = '';
    for (const stat in stats) {
        if (stats.hasOwnProperty(stat)) {
            const value = stats[stat];
            const percentage = Math.min((value / 150) * 100, 100); // Assuming 150 is the max stat value
            statsHTML += `
                <div class="stat-item">
                    <span>${stat}:</span>
                    <div class="stat-bar">
                        <div class="progress" style="width: ${percentage}%;"></div>
                    </div>
                </div>
            `;
        }
    }
    return statsHTML;
}

/**
 * Loads a 3D model using Three.js and GLTFLoader.
 * @param {string} modelName - The name of the model file (without extension).
 * @param {string} containerId - The ID of the container where the model will be rendered.
 */
function loadCreatureModel(modelName, containerId) {
    const modelPath = `models/${modelName}.glb`;
    const container = document.getElementById(containerId);

    if (!container) return;

    // Initialize Three.js Scene
    const scene = new THREE.Scene();

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
        75,
        container.clientWidth / container.clientHeight,
        0.1,
        1000
    );
    camera.position.z = 5;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 1);
    scene.add(ambientLight);

    // GLTFLoader to load the model
    const loader = new THREE.GLTFLoader();
    loader.load(
        modelPath,
        function (gltf) {
            scene.add(gltf.scene);
            animate();
        },
        undefined,
        function (error) {
            console.error('An error occurred while loading the model:', error);
        }
    );

    // Animation loop
    function animate() {
        requestAnimationFrame(animate);
        renderer.render(scene, camera);
    }

    // Handle window resize
    window.addEventListener('resize', () => {
        const width = container.clientWidth;
        const height = container.clientHeight;
        renderer.setSize(width, height);
        camera.aspect = width / height;
        camera.updateProjectionMatrix();
    });
}

/**
 * Populates and opens the bestiary modal.
 */
function openBestiary() {
    const bestiaryModal = document.getElementById('bestiaryModal');
    populateBestiaryModal();
    bestiaryModal.classList.add('show');
    bestiaryModal.setAttribute('aria-hidden', 'false');
}

/**
 * Closes the bestiary modal.
 */
function closeBestiary() {
    const bestiaryModal = document.getElementById('bestiaryModal');
    bestiaryModal.classList.remove('show');
    bestiaryModal.setAttribute('aria-hidden', 'true');
}

/**
 * Populates the bestiary modal with all races.
 */
function populateBestiaryModal() {
    renderBestiary();
}

/**
 * Closes the creature details modal.
 * @param {string} creatureKey - The key of the creature to close details for.
 */
function closeCreatureDetails(creatureKey) {
    const detailsModal = document.getElementById('creatureDetailsModal');
    detailsModal.classList.remove('show');
    detailsModal.setAttribute('aria-hidden', 'true');

    // Optionally, remove the 3D model to free up resources
    const modelContainer = document.getElementById(`model-container-${creatureKey}`);
    if (modelContainer) {
        modelContainer.innerHTML = '';
    }
}
