// objects.js - Game objects creation
class ObjectFactory {
    constructor() {
        // Initialize geometries and materials
    }
    
    // Move all object creation methods here (createTree, createRock, etc.)
}

export { ObjectFactory };