// crafting.js - Crafting system
class Crafting {
    constructor() {
        this.grid = Array(4).fill(null);
        this.result = null;
    }
    
    // Move all crafting-related methods here
}

export { Crafting };
